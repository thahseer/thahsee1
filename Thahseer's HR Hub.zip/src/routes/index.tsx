import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";
import videoAsset from "@/assets/thahseer-intro.asset.json";
import resumeAsset from "@/assets/thahseer-resume.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Thahseer Pari — HR Generalist & PRO Specialist | Abu Dhabi" },
      { name: "description", content: "CHRP-certified HR leader in Abu Dhabi. 35+ branches, 450+ employees. MOHRE, ICP, TAMM, WPS expert. Immediate joiner — open for interviews." },
      { name: "theme-color", content: "#05030f" },
      { property: "og:title", content: "Thahseer Pari — HR Generalist & PRO Specialist" },
      { property: "og:description", content: "Human Capital Management professional with 5+ years of UAE multi-entity HR leadership. Available for interviews." },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Person",
        name: "Thahseer Pari",
        jobTitle: "HR Generalist & PRO Specialist",
        address: { "@type": "PostalAddress", addressLocality: "Abu Dhabi", addressCountry: "AE" },
        email: "thahseer2011@gmail.com",
        telephone: "+971567611880",
      }),
    }],
  }),
  component: Index,
});

const NAV = [
  { id: "about", label: "About" },
  { id: "experience", label: "Experience" },
  { id: "skills", label: "Skills" },
  { id: "certifications", label: "Certifications" },
  { id: "contact", label: "Contact" },
];

const STATS = [
  { value: 35, suffix: "+", label: "Branches Managed" },
  { value: 450, suffix: "+", label: "Employees Led" },
  { value: 25, suffix: "%", label: "Turnover Reduced" },
  { value: 40, suffix: "%", label: "Absenteeism Cut" },
];

const PILLS = ["CHRP Certified", "AI Automation · n8n", "Power BI · Tableau", "MOHRE · ICP · TAMM"];

const EXPERIENCE = [
  {
    role: "HR Generalist — Human Capital Management",
    company: "Al Awadhi Group",
    location: "Abu Dhabi, UAE",
    tags: ["Jewellery", "Pharmacy", "Retail", "Real Estate", "Automotive"],
    period: "Jun 2024 – Present",
    bullets: [
      "Spearheaded HR operations for 35+ branches across 7 entities managing 450+ employees.",
      "Designed company-wide SOPs and complete organisational hierarchy from scratch.",
      "Achieved 25% reduction in turnover and 40% reduction in absenteeism.",
      "Implemented HRMS achieving 100% WPS compliance and UAE Labour Law alignment.",
      "Drove KPI frameworks, workforce planning, and HR analytics for leadership decisions.",
    ],
  },
  {
    role: "HR Generalist cum PRO",
    company: "Le Patchouli Specialty Coffee & Restaurant",
    location: "Abu Dhabi, UAE",
    tags: ["F&B Industry"],
    period: "Jan 2021 – May 2024",
    bullets: [
      "Led HR & PRO operations across 14+ branches managing 250+ employees.",
      "Achieved 95% grievance resolution rate through structured mediation frameworks.",
      "Processed all MOHRE, ICP, Tasheel, TAMM, AMER, DED, Daman, Muroor — zero penalties.",
      "Designed HR policies, leave management, and KPI appraisal systems.",
    ],
  },
  {
    role: "HR Assistant",
    company: "RM Tawjeeh Center",
    location: "Abu Dhabi, UAE",
    tags: [],
    period: "Jan 2019 – Feb 2021",
    bullets: [
      "Supported end-to-end HR administration: onboarding, payroll, leave, HRIS.",
      "Coordinated MOHRE, Emirates ID, full recruitment cycle management.",
    ],
  },
  {
    role: "Public Relations Officer (PRO)",
    company: "Interact Business Integrity",
    location: "Abu Dhabi, UAE",
    tags: [],
    period: "Feb 2017 – Jan 2019",
    bullets: [
      "Managed employment visas, work permits, DED trade licences via government portals.",
      "Liaised with MOHRE, ICA, DED, Tasheel for full regulatory compliance.",
    ],
  },
];

const SKILLS = [
  {
    title: "UAE Government Portals",
    items: ["MOHRE Portal", "ICP / Immigration", "Tasheel", "TAMM Abu Dhabi", "AMER Centre", "DED", "Daman Health Insurance", "Muroor", "NAFIS", "WPS", "Exchange Online Portal"],
  },
  {
    title: "Human Capital Management",
    items: ["UAE Labour Law", "Emiratisation", "Payroll & WPS", "Recruitment", "Performance KPI", "Employee Relations", "Grievance Handling", "SOP Design", "HRMS / ERP", "Workforce Planning", "Org Structure Design"],
  },
  {
    title: "AI & Data Analytics",
    items: ["AI Prompt Engineering", "n8n Automation", "Python", "Power BI", "Tableau", "SQL / MySQL", "Microsoft Excel Advanced", "HR Process Automation"],
  },
];

const CERTIFICATIONS = [
  { title: "Bachelor of Business Administration (BBA)", sub: "Albedo School of Business Management" },
  { title: "Certified HR Professional (CHRP)", sub: "Time Training Center, UAE" },
  { title: "AI Prompt Engineering Certification", sub: "2024 – 2025" },
  { title: "Data Analysis Certificate", sub: "Python · Power BI · Tableau · SQL · Excel — 2025" },
  { title: "AI Automation Certificate (n8n)", sub: "Workflow Automation & AI Integration — 2025" },
  { title: "Diploma in Software Development", sub: "ARM College | 2014" },
  { title: "CCNA Certification", sub: "APTECH | 2020" },
];

const WHATSAPP_URL = "https://wa.me/971567611880?text=Hi%20Thahseer%2C%20I%20found%20your%20profile%20and%20would%20like%20to%20discuss%20an%20HR%20opportunity.";
const MAIL_TO = "thahseer2011@gmail.com";
const QR_URL = `https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=10&color=0d1530&bgcolor=ffffff&data=${encodeURIComponent("https://wa.me/971567611880")}`;
const MAP_EMBED = "https://www.google.com/maps?q=Abu%20Dhabi%2C%20UAE&z=11&output=embed";

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add("in");
          io.unobserve(e.target);
        }
      }),
      { threshold: 0.12 }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function useCounter(target: number, duration = 1800) {
  const [value, setValue] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting && !started.current) {
          started.current = true;
          const start = performance.now();
          const tick = (now: number) => {
            const p = Math.min((now - start) / duration, 1);
            const eased = 1 - Math.pow(1 - p, 3);
            setValue(Math.round(target * eased));
            if (p < 1) requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
        }
      });
    }, { threshold: 0.4 });
    io.observe(el);
    return () => io.disconnect();
  }, [target, duration]);
  return { ref, value };
}

function Counter({ target, suffix }: { target: number; suffix: string }) {
  const { ref, value } = useCounter(target);
  return (
    <span ref={ref}>
      {value}
      <span className="text-gold/80">{suffix}</span>
    </span>
  );
}

function Nav() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className={`no-print fixed inset-x-0 top-0 z-50 transition-all duration-500 ${scrolled ? "py-2" : "py-4"}`}>
      <div className={`mx-auto max-w-6xl px-4 transition-all duration-500 ${scrolled ? "" : ""}`}>
        <div className={`flex items-center justify-between rounded-2xl px-5 py-3 transition-all duration-500 ${scrolled ? "glass" : "bg-transparent"}`}>
          <a href="#top" className="font-display text-xl text-cream tracking-wide">
            Thahseer<span className="text-gold">.</span>
          </a>
          <nav className="hidden md:flex items-center gap-7">
            {NAV.map((n) => (
              <a key={n.id} href={`#${n.id}`} className="relative text-sm text-cream/75 hover:text-gold transition-colors group">
                {n.label}
                <span className="absolute -bottom-1 left-0 h-px w-0 bg-gold transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
            <a href="#contact" className="ripple rounded-full bg-gold px-5 py-2 text-sm font-medium text-navy-ink hover:bg-gold-soft transition shadow-[0_10px_30px_-10px_rgba(201,149,42,0.6)]">
              Hire Me
            </a>
          </nav>
          <button onClick={() => setOpen(!open)} className="md:hidden text-cream p-2" aria-label="Menu">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              {open ? <path d="M6 6l12 12M6 18L18 6" /> : <path d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
        </div>
      </div>
      {open && (
        <div className="md:hidden mx-4 mt-2 rounded-2xl glass overflow-hidden">
          <div className="flex flex-col px-5 py-4 gap-1">
            {NAV.map((n) => (
              <a key={n.id} href={`#${n.id}`} onClick={() => setOpen(false)} className="text-cream/90 py-2.5 border-b border-white/5 last:border-0">
                {n.label}
              </a>
            ))}
            <a href="#contact" onClick={() => setOpen(false)} className="mt-3 rounded-full bg-gold px-4 py-3 text-center font-medium text-navy-ink">
              Hire Me
            </a>
          </div>
        </div>
      )}
    </header>
  );
}

function Hero() {
  const [videoOpen, setVideoOpen] = useState(false);
  return (
    <section id="top" className="relative overflow-hidden pt-32 pb-24 md:pt-44 md:pb-32 min-h-screen flex items-center">
      {/* Atmosphere */}
      <div className="absolute top-[-10%] left-[-5%] h-[60%] w-[55%] rounded-full bg-[#5423e8]/25 blur-[160px] glow-pulse" />
      <div className="absolute bottom-[-15%] right-[-5%] h-[55%] w-[55%] rounded-full bg-[#bcb0ff]/15 blur-[180px] glow-pulse" />
      <div className="absolute inset-0 grid-dots animated-dots opacity-[0.12]" />

      <div className="relative mx-auto max-w-7xl w-full px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left content */}
          <div className="lg:col-span-7 space-y-8 md:space-y-10 reveal">
            <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full border border-white/10 bg-white/5">
              <span className="flex h-2 w-2 rounded-full bg-[#5423e8] animate-pulse" />
              <span className="text-[11px] uppercase tracking-[0.25em] font-bold text-[#bcb0ff]">CHRP Certified · Abu Dhabi · Open to Interviews</span>
            </div>

            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-[6rem] leading-[0.9] font-extrabold tracking-[-0.04em] text-white">
              Hi, I'm
              <br />
              <span className="gradient-text italic font-light">Thahseer</span>
              <span className="text-white"> Pari.</span>
            </h1>

            <p className="max-w-xl text-lg md:text-xl text-white/65 leading-relaxed font-light">
              An <span className="text-white font-medium">HR Generalist & PRO Specialist</span> based in Abu Dhabi with 5+ years of
              UAE multi-entity HR leadership across <span className="text-white font-medium">35+ branches</span> and{" "}
              <span className="text-white font-medium">450+ employees</span>. CHRP certified. Immediate joiner — available for interviews.
            </p>

            <div className="flex flex-wrap items-center gap-5 pt-2">
              <a
                href="#contact"
                className="ripple group inline-flex items-center gap-2 px-8 py-4 md:px-9 md:py-4 rounded-2xl bg-[#5423e8] hover:bg-[#6a3ff0] transition-all font-bold text-base md:text-lg text-white shadow-[0_20px_50px_-12px_rgba(84,35,232,0.6)] hover:scale-[1.03]"
              >
                Schedule Interview
                <span className="transition-transform group-hover:translate-x-1">→</span>
              </a>
              <a
                href={resumeAsset.url}
                download="Thahseer-Pari-Resume.pdf"
                className="ripple inline-flex items-center gap-3 px-8 py-4 md:px-9 md:py-4 rounded-2xl border border-white/15 hover:border-[#bcb0ff]/50 hover:bg-white/5 transition font-bold text-base md:text-lg text-white"
              >
                <span className="flex h-2 w-2 rounded-full bg-[#bcb0ff] animate-pulse" />
                Download CV
              </a>
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              {PILLS.map((p) => (
                <span key={p} className="rounded-full bg-white/5 border border-white/10 px-3.5 py-1.5 text-[11px] text-white/70 tracking-wide">
                  {p}
                </span>
              ))}
            </div>
          </div>

          {/* Right floating analytics stack */}
          <div className="lg:col-span-5 relative reveal">
            <div className="relative mx-auto max-w-md aspect-[4/5]">
              {/* Stage card */}
              <div className="absolute inset-0 rounded-[48px] bg-gradient-to-br from-[#5423e8]/30 via-[#1a1f5e]/40 to-[#000629] border border-white/10 overflow-hidden shadow-[0_40px_120px_-20px_rgba(84,35,232,0.4)]">
                <div className="absolute inset-0 grid-dots opacity-20" />
                <div className="absolute -top-20 -right-20 h-72 w-72 rounded-full bg-[#5423e8]/40 blur-3xl" />
                <div className="absolute bottom-0 left-0 right-0 p-8 text-center">
                  <div className="text-[10px] uppercase tracking-[0.4em] text-[#bcb0ff] font-bold">Human Capital</div>
                  <div className="mt-2 text-7xl font-extrabold text-white/15 italic tracking-tighter select-none">HR</div>
                </div>
              </div>

              {/* Floating metric — years */}
              <div className="absolute -left-6 md:-left-12 top-12 float-slow">
                <div className="glass p-5 md:p-6 rounded-3xl">
                  <div className="text-3xl md:text-4xl font-extrabold text-white">5+</div>
                  <div className="text-[10px] uppercase tracking-widest text-[#bcb0ff] mt-1 font-bold">Years Exp</div>
                </div>
              </div>

              {/* Floating metric — brands */}
              <div className="absolute -right-4 md:-right-10 top-1/2 float-slower">
                <div className="glass p-5 md:p-6 rounded-3xl flex items-center gap-4">
                  <div className="w-11 h-11 md:w-12 md:h-12 rounded-xl bg-[#5423e8] flex items-center justify-center shrink-0">
                    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 4a2 2 0 114 0v1a2 2 0 002 2h3a2 2 0 012 2v11a2 2 0 01-2 2H3a2 2 0 01-2-2V9a2 2 0 012-2h3a2 2 0 002-2V5a2 2 0 012-2z" /></svg>
                  </div>
                  <div>
                    <div className="text-xl md:text-2xl font-extrabold text-white">35+</div>
                    <div className="text-[9px] uppercase tracking-widest text-white/55 font-bold">Branches</div>
                  </div>
                </div>
              </div>

              {/* Floating metric — employees */}
              <div className="absolute left-6 -bottom-6 md:-bottom-8 float-slow">
                <div className="glass p-5 md:p-6 rounded-3xl flex items-center gap-4">
                  <div className="w-11 h-11 md:w-12 md:h-12 rounded-xl bg-[#bcb0ff]/20 border border-[#bcb0ff]/30 flex items-center justify-center shrink-0">
                    <svg className="w-6 h-6 text-[#bcb0ff]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                  </div>
                  <div>
                    <div className="text-xl md:text-2xl font-extrabold text-white">450+</div>
                    <div className="text-[9px] uppercase tracking-widest text-white/55 font-bold">Employees</div>
                  </div>
                </div>
              </div>

              {/* CHRP badge — gold */}
              <div className="absolute -top-4 right-8 -rotate-12">
                <div className="h-16 w-16 rounded-full bg-gradient-to-br from-[#e8c97a] to-[#c9a24a] text-[#05030f] flex items-center justify-center font-black text-xs shadow-[0_0_30px_rgba(201,162,74,0.55)] ring-2 ring-[#c9a24a]/40">
                  CHRP
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stat counters strip */}
        <div className="mt-20 md:mt-28 grid grid-cols-2 md:grid-cols-4 gap-4 reveal">
          {STATS.map((s) => (
            <div key={s.label} className="glass hover-lift rounded-2xl p-5 md:p-6 text-center">
              <div className="text-3xl md:text-4xl font-extrabold text-white leading-none">
                <Counter target={s.value} suffix={s.suffix} />
              </div>
              <div className="mt-2.5 text-[9px] uppercase tracking-[0.22em] text-[#bcb0ff]/80 font-bold">{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {videoOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 backdrop-blur p-4 no-print" onClick={() => setVideoOpen(false)}>
          <div className="relative w-full max-w-3xl" onClick={(e) => e.stopPropagation()}>
            <button onClick={() => setVideoOpen(false)} className="absolute -top-10 right-0 text-white hover:text-[#bcb0ff] tracking-wide text-sm">Close</button>
            <video src={videoAsset.url} controls autoPlay className="w-full rounded-2xl border border-[#5423e8]/50" />
          </div>
        </div>
      )}
    </section>
  );
}

function About() {
  return (
    <section id="about" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute -left-40 top-1/3 h-96 w-96 rounded-full bg-gold/8 blur-[120px]" />
      <div className="relative mx-auto max-w-4xl px-5">
        <p className="reveal text-sm uppercase tracking-[0.25em] text-gold mb-3">Profile</p>
        <h2 className="reveal font-display text-4xl md:text-5xl text-cream section-title">About Me</h2>
        <p className="reveal mt-8 text-lg leading-relaxed text-cream/80">
          I'm a <strong className="text-gold">Human Capital Management professional</strong> with 5+ years of progressive HR leadership experience managing complex multi-entity operations across F&B, Jewellery, Pharmacy, Retail, and Real Estate sectors in the UAE. I've led workforce operations for <strong className="text-cream">450+ employees across 35+ branches</strong> at Al Awadhi Group and <strong className="text-cream">250+ employees across 14+ branches</strong> at Le Patchouli — designing enterprise SOPs, building complete organisational hierarchies, and delivering measurable improvements in workforce performance and retention.
        </p>
        <p className="reveal mt-5 text-lg leading-relaxed text-cream/70">
          Deep expertise across UAE government portals — MOHRE, ICP, Tasheel, TAMM, AMER, DED, Daman, Muroor, WPS — ensuring zero-penalty compliance across multi-branch operations. A Certified Human Resource Professional (CHRP) combining strategic vision, operational precision, and digital fluency. <strong className="text-cream">Currently available for interviews and ready to join immediately.</strong>
        </p>
      </div>
    </section>
  );
}

function Experience() {
  return (
    <section id="experience" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute right-0 top-20 h-80 w-80 rounded-full bg-navy-soft/15 blur-[120px]" />
      <div className="relative mx-auto max-w-5xl px-5">
        <p className="reveal text-sm uppercase tracking-[0.25em] text-gold mb-3">Journey</p>
        <h2 className="reveal font-display text-4xl md:text-5xl text-cream section-title mb-14">Work Experience</h2>

        <div className="relative">
          <div className="absolute left-3 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-gold/0 via-gold/50 to-gold/0 -translate-x-px" />
          <div className="space-y-12">
            {EXPERIENCE.map((job, i) => (
              <div key={job.company} className={`reveal relative md:grid md:grid-cols-2 md:gap-12 ${i % 2 === 0 ? "" : "md:[&>*:first-child]:order-2"}`}>
                <div className="absolute left-3 md:left-1/2 top-2 h-4 w-4 -translate-x-1/2 rounded-full bg-gold ring-4 ring-navy-ink shadow-[0_0_20px_rgba(201,149,42,0.5)]" />
                <div className={`pl-10 md:pl-0 ${i % 2 === 0 ? "md:text-right md:pr-10" : "md:pl-10"}`}>
                  <div className="text-xs uppercase tracking-widest text-gold font-medium">{job.period}</div>
                  <h3 className="mt-2 font-display text-2xl text-cream">{job.role}</h3>
                  <div className="mt-1 text-gold-soft font-medium">{job.company}</div>
                  <div className="text-sm text-cream/55">{job.location}</div>
                  {job.tags.length > 0 && (
                    <div className={`mt-3 flex flex-wrap gap-1.5 ${i % 2 === 0 ? "md:justify-end" : ""}`}>
                      {job.tags.map((t) => (
                        <span key={t} className="rounded-full glass px-2.5 py-0.5 text-xs text-cream/75">{t}</span>
                      ))}
                    </div>
                  )}
                </div>
                <div className="pl-10 md:pl-0 mt-4 md:mt-0">
                  <div className="glass rounded-2xl p-6 hover-lift">
                    <ul className="space-y-2.5 text-cream/75 leading-relaxed">
                      {job.bullets.map((b) => (
                        <li key={b} className="flex gap-2.5 text-sm md:text-[15px]">
                          <span className="text-gold mt-1.5 shrink-0">◆</span>
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Skills() {
  return (
    <section id="skills" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute left-1/2 top-0 -translate-x-1/2 h-64 w-[600px] rounded-full bg-gold/8 blur-[120px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <p className="reveal text-sm uppercase tracking-[0.25em] text-gold mb-3">Capabilities</p>
        <h2 className="reveal font-display text-4xl md:text-5xl text-cream section-title mb-14">Skills & Expertise</h2>
        <div className="grid gap-6 md:grid-cols-3">
          {SKILLS.map((s) => (
            <div key={s.title} className="reveal glass hover-lift group rounded-2xl p-7">
              <h3 className="font-display text-2xl text-cream mb-4">{s.title}</h3>
              <div className="h-px w-12 bg-gold mb-5" />
              <ul className="flex flex-wrap gap-1.5">
                {s.items.map((it) => (
                  <li key={it} className="rounded-md bg-white/[0.04] border border-white/5 px-2.5 py-1 text-xs text-cream/75 group-hover:border-gold/20 transition">{it}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Certifications() {
  return (
    <section id="certifications" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute right-1/4 top-1/2 h-72 w-72 rounded-full bg-navy-soft/15 blur-[100px]" />
      <div className="relative mx-auto max-w-6xl px-5">
        <p className="reveal text-sm uppercase tracking-[0.25em] text-gold mb-3">Credentials</p>
        <h2 className="reveal font-display text-4xl md:text-5xl text-cream section-title mb-14">Education & Certifications</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {CERTIFICATIONS.map((c) => (
            <div key={c.title} className="reveal glass rounded-xl border-l-2 border-l-gold p-5 hover-lift">
              <h3 className="font-display text-lg text-cream leading-tight">{c.title}</h3>
              <p className="mt-1.5 text-sm text-cream/60">{c.sub}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function DownloadResume() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-4xl px-5 text-center reveal">
        <div className="relative rounded-3xl glass-gold p-10 md:p-14 overflow-hidden">
          <div className="absolute inset-0 grid-dots opacity-25" />
          <div className="absolute -top-20 -right-20 h-60 w-60 rounded-full bg-gold/20 blur-3xl glow-pulse" />
          <div className="relative">
            <h2 className="font-display text-3xl md:text-4xl text-cream">Take My Resume With You</h2>
            <p className="mt-3 text-cream/70">Full CV including experience, certifications and references.</p>
            <a
              href={resumeAsset.url}
              download="Thahseer-Pari-Resume.pdf"
              className="ripple mt-7 inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3.5 font-medium text-navy-ink hover:bg-gold-soft transition shadow-[0_15px_40px_-10px_rgba(201,149,42,0.6)] no-print tracking-wide"
            >
              Download Resume
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function ContactForm() {
  const [status, setStatus] = useState<"idle" | "ok" | "error">("idle");
  const [errors, setErrors] = useState<Record<string, string>>({});

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const name = String(data.get("name") || "").trim();
    const email = String(data.get("email") || "").trim();
    const message = String(data.get("message") || "").trim();

    const errs: Record<string, string> = {};
    if (!name || name.length > 100) errs.name = "Please enter your name (max 100).";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255) errs.email = "Enter a valid email.";
    if (!message || message.length > 1500) errs.message = "Message required (max 1500).";
    if (Object.keys(errs).length) {
      setErrors(errs);
      setStatus("error");
      return;
    }

    const subject = `Interview Opportunity from ${name}`;
    const body = `${message}\n\n— ${name}\n${email}`;
    window.location.href = `mailto:${MAIL_TO}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setStatus("ok");
    setErrors({});
    form.reset();
  }

  return (
    <form onSubmit={onSubmit} className="glass rounded-2xl p-6 md:p-8 space-y-4" noValidate>
      <div className="grid gap-4 md:grid-cols-2">
        <label className="block">
          <span className="text-[10px] uppercase tracking-[0.2em] text-gold">Name</span>
          <input name="name" maxLength={100} required className="mt-1.5 w-full rounded-lg bg-white/5 border border-white/10 px-4 py-3 text-cream placeholder-cream/30 focus:outline-none focus:border-gold transition" placeholder="Your full name" />
          {errors.name && <span className="text-xs text-red-300 mt-1 block">{errors.name}</span>}
        </label>
        <label className="block">
          <span className="text-[10px] uppercase tracking-[0.2em] text-gold">Email</span>
          <input type="email" name="email" maxLength={255} required className="mt-1.5 w-full rounded-lg bg-white/5 border border-white/10 px-4 py-3 text-cream placeholder-cream/30 focus:outline-none focus:border-gold transition" placeholder="you@company.com" />
          {errors.email && <span className="text-xs text-red-300 mt-1 block">{errors.email}</span>}
        </label>
      </div>
      <label className="block">
        <span className="text-[10px] uppercase tracking-[0.2em] text-gold">Message</span>
        <textarea name="message" rows={5} maxLength={1500} required className="mt-1.5 w-full rounded-lg bg-white/5 border border-white/10 px-4 py-3 text-cream placeholder-cream/30 focus:outline-none focus:border-gold transition resize-none" placeholder="Tell me about the role or opportunity…" />
        {errors.message && <span className="text-xs text-red-300 mt-1 block">{errors.message}</span>}
      </label>
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <button type="submit" className="ripple inline-flex items-center gap-2 rounded-full bg-gold px-7 py-3 font-medium text-navy-ink hover:bg-gold-soft transition shadow-[0_10px_30px_-10px_rgba(201,149,42,0.6)] tracking-wide">
          Send Message
          <span>→</span>
        </button>
        {status === "ok" && <span className="text-xs text-emerald-300">Opening your email client…</span>}
      </div>
    </form>
  );
}

function Contact() {
  return (
    <section id="contact" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute inset-0 grid-dots opacity-25" />
      <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-gold/15 blur-3xl" />
      <div className="absolute -bottom-32 -right-32 h-96 w-96 rounded-full bg-navy-soft/20 blur-3xl" />
      <div className="relative mx-auto max-w-6xl px-5">
        <div className="text-center mb-14">
          <p className="reveal text-sm uppercase tracking-[0.25em] text-gold mb-3">Get in touch</p>
          <h2 className="reveal font-display text-4xl md:text-5xl text-cream inline-block section-title">Let's Work Together</h2>
        </div>

        <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
          <div className="reveal space-y-6">
            <div className="glass rounded-2xl p-6 md:p-8">
              <ul className="space-y-4 text-cream/85">
                <li className="flex items-center gap-4">
                  <span className="text-[10px] uppercase tracking-widest text-gold w-20 shrink-0">Phone</span>
                  <a href="tel:+971567611880" className="hover:text-gold transition">+971 56 761 1880</a>
                </li>
                <li className="flex items-center gap-4">
                  <span className="text-[10px] uppercase tracking-widest text-gold w-20 shrink-0">Email</span>
                  <a href={`mailto:${MAIL_TO}`} className="hover:text-gold transition break-all">{MAIL_TO}</a>
                </li>
                <li className="flex items-center gap-4">
                  <span className="text-[10px] uppercase tracking-widest text-gold w-20 shrink-0">Location</span>
                  <span>Abu Dhabi, UAE</span>
                </li>
                <li className="flex items-center gap-4">
                  <span className="text-[10px] uppercase tracking-widest text-gold w-20 shrink-0">Status</span>
                  <span>UAE Resident — Immediate Joiner</span>
                </li>
              </ul>
              <div className="mt-6 flex flex-wrap gap-3 no-print">
                <a href={WHATSAPP_URL} target="_blank" rel="noopener" className="ripple inline-flex items-center gap-2 rounded-full bg-gold px-6 py-3 font-medium text-navy-ink hover:bg-gold-soft transition shadow-[0_10px_30px_-10px_rgba(201,149,42,0.5)] tracking-wide text-sm">
                  WhatsApp
                </a>
                <a href={`mailto:${MAIL_TO}`} className="inline-flex items-center gap-2 rounded-full glass px-6 py-3 font-medium text-cream hover:text-gold transition tracking-wide text-sm">
                  Email
                </a>
              </div>
            </div>

            <div className="glass rounded-2xl overflow-hidden border-gold/20">
              <iframe
                src={MAP_EMBED}
                title="Abu Dhabi, UAE — Location"
                width="100%"
                height="260"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                style={{ border: 0, filter: "grayscale(0.4) contrast(1.05) brightness(0.85)" }}
                allowFullScreen
              />
            </div>

            <div className="reveal glass-gold rounded-2xl p-5 flex items-center gap-5">
              <div className="rounded-lg bg-white p-2 shrink-0">
                <img src={QR_URL} alt="WhatsApp QR Code" className="h-24 w-24" />
              </div>
              <div className="min-w-0">
                <div className="font-display text-lg text-cream">Scan to Chat on WhatsApp</div>
                <div className="text-xs text-cream/60 mt-1">Open your phone camera and scan</div>
              </div>
            </div>
          </div>

          <div className="reveal">
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const details = [
    ["Nationality", "Indian"],
    ["Date of Birth", "10 May 1987"],
    ["Marital Status", "Married"],
    ["Visa Status", "UAE Resident"],
    ["Driving Licence", "UAE & Indian"],
    ["Languages", "English · Arabic · Malayalam · Hindi"],
  ];
  return (
    <footer className="relative py-14 border-t border-white/10">
      <div className="absolute inset-0 grid-dots opacity-10" />
      <div className="relative mx-auto max-w-6xl px-5">
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
          {details.map(([k, v]) => (
            <div key={k} className="text-sm">
              <div className="text-[10px] uppercase tracking-widest text-gold/80">{k}</div>
              <div className="mt-0.5 text-cream/75">{v}</div>
            </div>
          ))}
        </div>
        <div className="mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row sm:justify-between gap-3 text-xs text-cream/55">
          <div>© {new Date().getFullYear()} Thahseer Pari. References available upon request.</div>
          <div className="flex items-center gap-4">
            <a href={WHATSAPP_URL} target="_blank" rel="noopener" className="hover:text-gold transition">WhatsApp</a>
            <a href={`mailto:${MAIL_TO}`} className="hover:text-gold transition">Email</a>
            <span>Abu Dhabi · CHRP</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

function Index() {
  useReveal();
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      const t = e.target as HTMLElement;
      const el = t.closest<HTMLElement>(".ripple");
      if (!el) return;
      const r = el.getBoundingClientRect();
      el.style.setProperty("--x", `${e.clientX - r.left}px`);
      el.style.setProperty("--y", `${e.clientY - r.top}px`);
    };
    document.addEventListener("mousemove", handler);
    return () => document.removeEventListener("mousemove", handler);
  }, []);
  return (
    <div className="text-cream">
      <Nav />
      <main>
        <Hero />
        <About />
        <Experience />
        <Skills />
        <Certifications />
        <DownloadResume />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
